package com.gok.gok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GokApplicationTests {

	@Test
	void contextLoads() {
	}

}
