package com.gok.gok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GokApplication {

	public static void main(String[] args) {
		SpringApplication.run(GokApplication.class, args);
	}

}
