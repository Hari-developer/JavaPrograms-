package com.gok.gok.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/api/")
public class controler {

@RequestMapping(value="testAPI",method=RequestMethod.GET)
		public ResponseEntity<?> testApi(@RequestParam Map<String, String> requestParam) throws Exception
		{
			requestParam.put("Hari", "gokul");
		requestParam.put("Status", "Success");
		requestParam.put("Hello", "World");
	System.out.println(requestParam.isEmpty()); 
		return new ResponseEntity<>(requestParam, HttpStatus.OK);
		}
		}


